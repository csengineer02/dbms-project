<?php
require_once("../../config/db.php");
$data=json_decode(file_get_contents("php://input"),true);
$name=$data['name']??'';
$phone=$data['phone']??'';
$password=$data['password']??'';
$role=$data['role']??'customer';
$hash=password_hash($password,PASSWORD_DEFAULT);
$stmt=$conn->prepare("INSERT INTO users(name,phone,password_hash,role) VALUES(?,?,?,?)");
$stmt->bind_param("ssss",$name,$phone,$hash,$role);
if($stmt->execute()){ echo json_encode(["success"=>true]); }
else{ http_response_code(400); echo json_encode(["error"=>"User exists"]); }
?>