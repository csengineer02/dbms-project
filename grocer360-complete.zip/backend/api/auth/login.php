<?php
require_once("../../config/db.php");
$data=json_decode(file_get_contents("php://input"),true);
$phone=$data['phone']??'';
$password=$data['password']??'';
$res=$conn->query("SELECT * FROM users WHERE phone='$phone'");
if($res && $res->num_rows>0){
 $u=$res->fetch_assoc();
 if(password_verify($password,$u['password_hash'])){
   unset($u['password_hash']);
   echo json_encode(["success"=>true,"user"=>$u]);
   exit;
 }
}
http_response_code(401); echo json_encode(["error"=>"Invalid login"]);
?>