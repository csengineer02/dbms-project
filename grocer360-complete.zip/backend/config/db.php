<?php
$conn = new mysqli("localhost","root","","grocer360");
if($conn->connect_error){ die("DB connection failed"); }
?>